
EncoderRadius = 24; %mm
EncoderWidth = 62; %mils
EncoderResolution = 3.6; %