Loading Instructions

1. Type "System" into the Matlab Command Window with the extracted folder as the directory to load the Workspace
2. Run the Simulink model "SystemModel" 