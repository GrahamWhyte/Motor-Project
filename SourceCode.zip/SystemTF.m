function [ FX ] = SystemTF( Elecn, Elecd, Mechn, Mechd, SpdK )
%SYSTEMTF Outputs system Transfer Fucntion from Elec and Mech Dynamics
    FX = feedback(tf(Elecn,Elecd)*tf(Mechn,Mechd)*SpdK, SpdK);
end

