%This is the datasheet for a MMMC 2.3W, 24 V, Brushless DC Motor
MotorParam = ...
...             % Nominal Values
[24             % NomV          (V)
 13242          % NoLoadSpd     (rpm)
 0.035          % NoLoadCurr    (A)
 11139          % NomSpd        (rpm)
 1.96           % NomTorque     (mNm)
 0.159          % NomCurr       (A)
 12.3           % StallTorque   (mNm)
 0.815          % StallCurr     (A)
...
                % Characteristics
 70             % TermR         (Ohms)
 2.00           % TermL (mH) (EST from compareable Maxon motor)
 14.9           % TorqueConst   (mNm/A)
 0.00           % SpdConst      (RPM/V)
 0.200          % RotJ    (gcm^2) (EST from compareable Maxon motor)      
 22.3           % Weight        (g)
...             % Physical Dimensions
 20.4           % OuterDiam     (mm)
 28.2];         % Length        (mm)