function [ fdata ] = formatData(data)
k = 1;    
for i = 2:length(data)
    if(data(i) < data(i-1))
        index(k) = i;
        k = k + 1;
    end
end
fdata = data;
inc = 1;
for i = 1:length(index)
    if(i == length(index))
        fdata(index(i):length(data)) = data(index(i):length(data)) + 2^16*inc;
    else
        fdata(index(i):(index(i+1)-1)) = data(index(i):(index(i+1)-1)) + 2^16*inc;
    end
    inc = inc + 1;
end
fdata = (fdata - min(fdata))*1e-6;
end